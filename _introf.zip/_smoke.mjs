import { chromium } from 'playwright';
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
const ctx = await b.newContext({ viewport: { width: 390, height: 844 }, serviceWorkers: 'block' });
const p = await ctx.newPage();
await p.goto('https://kentjuno.github.io/quan-bun/', { waitUntil: 'networkidle' }); await p.waitForTimeout(3500);
console.log('setup?', await p.evaluate(()=>!!document.querySelector('#setup')));
await p.click('#setup .su-langs button[data-l="en"]'); await p.waitForTimeout(500);
await p.fill('#suName','Mai'); await p.click('#setup .su-gender button[data-g="f"]'); await p.click('#suGo');
await p.waitForTimeout(1200);
console.log('intro?', await p.evaluate(()=>!!document.querySelector('#scene.intro')));
await p.screenshot({ path: '/mnt/user-data/outputs/live-intro.png' });
for (let i=0;i<6;i++){ await p.click('#scene').catch(()=>{}); await p.waitForTimeout(450); }
await p.click('#btnStart').catch(()=>{}); await p.waitForTimeout(1500);
console.log('owner:', await p.evaluate(()=>document.querySelector('#scene .sc-bubble')?.innerText?.replace(/\s+/g,' ').slice(0,120)));
await b.close();
